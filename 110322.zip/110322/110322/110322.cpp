﻿// 110322.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <locale.h>

using namespace std;

struct Node {
	
	Node(int value) 
	{
		Value = value;
		next = nullptr;
	}
	int Value;

	Node *next;
};
class List {
private:
	Node *head;

	Node* last() {
		if (head == nullptr) return nullptr;
		Node* current = head;
		while (current->next != nullptr)
		{
			current = current->next;
		}
		return current;
	}
public:
	List() 
	{
		head = nullptr;
	}
	void push_back(int value) 
	{
		if (head == nullptr) 
		{
			head = new Node(value);
			return;
		}

		Node* lastNode = last();
		if (lastNode != nullptr) 
		{
			lastNode->next = new Node(value);
		}
	}
	void print(){ 
		Node* current = head;

		while (current != nullptr)
		{
			std::cout << current->Value << " ";
			current = current->next;
		}
	}
	int size()
	{
		int i = 0;
		Node* current = head;
		while (current != nullptr)
		{
			i++;
			current = current->next;
			
		}
		std::cout << "Количество элементов: ";
		std::cout << i;
		return i;
	}
};

int main()
{
	setlocale(LC_ALL, "RUS");
	List list;

	list.push_back(3);
	list.push_back(1);
	list.push_back(4);
	list.push_back(7);
	list.push_back(987);
	list.print();
	list.size();

	return 0;
}
